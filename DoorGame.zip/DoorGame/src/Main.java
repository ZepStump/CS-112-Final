

public class Main 
{
	public static void main(String[] args)
	{
	
	DriverClass game = new DriverClass();
	
	game.setVisible(true);
	}
}
